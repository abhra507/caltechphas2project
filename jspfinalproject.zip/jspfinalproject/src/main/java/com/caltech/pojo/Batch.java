package com.caltech.pojo;

public class Batch {
private int bid;
private String bhrs;
private String instructor;
private String ptime;
private String pdate;
/**
 * @return the bid
 */
public int getBid() {
	return bid;
}
/**
 * @param bid the bid to set
 */
public void setBid(int bid) {
	this.bid = bid;
}
/**
 * @return the bhrs
 */
public String getBhrs() {
	return bhrs;
}
/**
 * @param bhrs the bhrs to set
 */
public void setBhrs(String bhrs) {
	this.bhrs = bhrs;
}
/**
 * @return the instructor
 */
public String getInstructor() {
	return instructor;
}
/**
 * @param instructor the instructor to set
 */
public void setInstructor(String instructor) {
	this.instructor = instructor;
}
/**
 * @return the ptime
 */
public String getPtime() {
	return ptime;
}
/**
 * @param ptime the ptime to set
 */
public void setPtime(String ptime) {
	this.ptime = ptime;
}
/**
 * @return the pdate
 */
public String getPdate() {
	return pdate;
}
/**
 * @param pdate the pdate to set
 */
public void setPdate(String pdate) {
	this.pdate = pdate;
}


	
	
}
