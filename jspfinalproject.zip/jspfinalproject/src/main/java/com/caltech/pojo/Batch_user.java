package com.caltech.pojo;

public class Batch_user {

	private String bhrs;
	private String instructor;
	private String ptime;
	private String pdate;
	private String username;
	/**
	 * @return the bhrs
	 */
	public String getBhrs() {
		return bhrs;
	}
	/**
	 * @param bhrs the bhrs to set
	 */
	public void setBhrs(String bhrs) {
		this.bhrs = bhrs;
	}
	/**
	 * @return the instructor
	 */
	public String getInstructor() {
		return instructor;
	}
	/**
	 * @param instructor the instructor to set
	 */
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	/**
	 * @return the ptime
	 */
	public String getPtime() {
		return ptime;
	}
	/**
	 * @param ptime the ptime to set
	 */
	public void setPtime(String ptime) {
		this.ptime = ptime;
	}
	/**
	 * @return the pdate
	 */
	public String getPdate() {
		return pdate;
	}
	/**
	 * @param pdate the pdate to set
	 */
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
}
