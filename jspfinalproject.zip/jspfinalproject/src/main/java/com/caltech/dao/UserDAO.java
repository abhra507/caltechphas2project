package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.User;

public class UserDAO {
	public Boolean validateLogin(String username , String password) throws ClassNotFoundException, SQLException
	{
		
			
		
		Boolean b =false;
		Connection con=DbUtil.getDbConn();
		String sql="select * from participants";
		PreparedStatement ps=con.prepareStatement(sql);
		//List<User> list=new ArrayList<>();
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			if(rs.getString("pname") .equals(username) && rs.getString("ppassword") .equals(password) )
			{
				b=true;
				return b;
			}
			
			if(rs.getString("pname") .equals(null) && rs.getString("ppassword") .equals(password))
			{
				b=false;
				return b;
				
			}
			if(rs.getString("pname") .equals(null) && rs.getString("ppassword") .equals(null))
			{
				b=false;
				return b;
				
			}
			
		}

	
		return false;
	
	}
	
	
	public int insert(User user) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="insert into participants (pname,pemail,ppassword) values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,user.getUsername());
		ps.setString(2,user.getUseremail());
		ps.setString(3,user.getPassword());
		return ps.executeUpdate();
		
	}
	
	public List<User> displayUser() throws ClassNotFoundException, SQLException{
		Connection con=DbUtil.getDbConn();
		String sql="select * from participants";
		PreparedStatement ps=con.prepareStatement(sql);
		List<User> list=new ArrayList<>();
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			User user=new User();
			user.setUserid(rs.getInt("pid"));
			user.setUsername(rs.getString("pname"));
			user.setUseremail(rs.getString("pemail"));
			user.setPassword(rs.getString("ppassword"));

			list.add(user);
		}
		return list;
		
	}
	
	public List<User> displayUserbyname(User user) throws ClassNotFoundException, SQLException{
		Connection con=DbUtil.getDbConn();
		String sql="select * from 	participants where pname=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,user.getUsername());
		List<User> list=new ArrayList<>();
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			User user1=new User();
			user1.setUserid(rs.getInt("pid"));
			user1.setUsername(rs.getString("pname"));
			user1.setUseremail(rs.getString("pemail"));
			list.add(user1);
		}
		return list;
		
	}
	
	
	public List<User> deleteUserById(int id) throws ClassNotFoundException, SQLException{
		Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("dB connection established ");
		}
		else {
			System.out.println("connection with dB failed ");
		}
		//Prepare the statement,Execution of the sql ,Close the connection
		String sql="delete from participants where pid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
		return displayUser();
		
	}


	public List<User> updateUserById(User user) throws ClassNotFoundException, SQLException{
	Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("dB connection established ");
		}
		else {
			System.out.println("connection with dB failed ");
		}
		
		String sql="update participants set pname=? where pid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,user.getUsername());
		ps.setInt(2, user.getUserid());
		ps.executeUpdate();
		ps.close();
		return displayUser();
		
	}


}
