package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.caltech.dbUtil.DbUtil;

public class AdminDAO {
	public Boolean validateLogin(String username , String password) throws ClassNotFoundException, SQLException
	{
		
			
		
		Boolean b =false;
		Connection con=DbUtil.getDbConn();
		String sql="select * from admintable";
		PreparedStatement ps=con.prepareStatement(sql);
		//List<User> list=new ArrayList<>();
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			if(rs.getString("username") .equals(username) && rs.getString("ppassword") .equals(password) )
			{
				b=true;
				return b;
			}
			
			if(rs.getString("username") .equals(null) && rs.getString("ppassword") .equals(password))
			{
				b=false;
				return b;
				
			}
			if(rs.getString("username") .equals(null) && rs.getString("ppassword") .equals(null))
			{
				b=false;
				return b;
				
			}
			
		}

	
		return false;
	
	}
}
