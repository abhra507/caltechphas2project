package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Batch;
import com.caltech.pojo.Batch_user;
import com.caltech.pojo.User;


public class BatchDAO {
//insert
	public int insert(Batch batch) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="insert into batch (bhrs,instructor,ptime,pdate) values(?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,batch.getBhrs());
		ps.setString(2,batch.getInstructor());
		ps.setString(3,batch.getPtime());
		ps.setString(4,batch.getPdate());
		return ps.executeUpdate();
		
	}
	
	//retrive
public List<Batch> displayBatch() throws ClassNotFoundException, SQLException{
	Connection con=DbUtil.getDbConn();
	String sql="select * from batch";
	PreparedStatement ps=con.prepareStatement(sql);
	List<Batch> list=new ArrayList<>();
	ResultSet rs=ps.executeQuery();
	while(rs.next()) {
		Batch batch=new Batch();
		batch.setBid(rs.getInt("bid"));
		batch.setBhrs(rs.getString("bhrs"));
		batch.setInstructor(rs.getString("instructor"));
		batch.setPtime(rs.getString("ptime"));
		batch.setPdate(rs.getString("pdate"));		
		list.add(batch);
	}
	return list;
	
}
	
//update 
/*public int edit(Product product) throws ClassNotFoundException, SQLException {
	Connection con=DbUtil.getDbConn();
	String sql="update product set pname=? where pid=?";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setString(1,product.getPname());
	ps.setInt(2, product.getPid());
	return ps.executeUpdate();
}*/


public List<Batch> deleteBatchById(int id) throws ClassNotFoundException, SQLException{
	Connection con=DbUtil.getDbConn();
	
	if(con!=null) {
		System.out.println("dB connection established ");
	}
	else {
		System.out.println("connection with dB failed ");
	}
	//Prepare the statement,Execution of the sql ,Close the connection
	String sql="delete from batch where bid=?";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setInt(1, id);
	ps.executeUpdate();
	ps.close();
	return displayBatch();
	
}


public List<Batch> updateBatchById(Batch batch) throws ClassNotFoundException, SQLException{
Connection con=DbUtil.getDbConn();
	
	if(con!=null) {
		System.out.println("dB connection established ");
	}
	else {
		System.out.println("connection with dB failed ");
	}
	
	String sql="update batch set instructor=? where bid=?";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setString(1,batch.getInstructor());
	ps.setInt(2, batch.getBid());
	ps.executeUpdate();
	ps.close();
	return displayBatch();
	
}


public int registerbatch(Batch batch,User user) throws ClassNotFoundException, SQLException {
	
	
	   Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("connection with DB established ");
		}
		else {
			System.out.println("connection failed ");
		}
		
		String sql="insert into participantbatch (pid,pname,bid) values(?,?,?)";
		
		PreparedStatement ps1=con.prepareStatement(sql);
		ps1.setInt(1, user.getUserid());	
		ps1.setString(2, user.getUsername());
		ps1.setInt(3, batch.getBid());
		
		return ps1.executeUpdate();
	
		
		
	}



public List<Batch_user> fetchbatchpostreg() throws ClassNotFoundException, SQLException {
	

	  Connection con=DbUtil.getDbConn();
		
		if(con!=null) {
			System.out.println("connection with DB established ");
		}
		else {
			System.out.println("connection failed ");
		}
			
		
		String sql="select b.bhrs,b.instructor,b.ptime,b.pdate,e.pname  from batch b INNER JOIN   participantbatch e on b.bid=e.bid" ;
		
		PreparedStatement ps1=con.prepareStatement(sql);
		List<Batch_user> list=new ArrayList<>();			
		ResultSet rs=ps1.executeQuery();//address of the table 
		
		
		while(rs.next()) {
			
			Batch_user batch=new Batch_user();
            batch.setBhrs(rs.getString("bhrs"));
            batch.setInstructor(rs.getString("instructor"));
            batch.setPdate(rs.getString("pdate"));
            batch.setPtime(rs.getString("ptime"));
            batch.setUsername(rs.getString("pname"));
            list.add(batch);       
		
}	
	
		return list;

}

}
